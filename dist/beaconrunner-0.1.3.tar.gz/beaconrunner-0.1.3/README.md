# Beacon Runner

An agent-based model of [eth2](https://github.com/ethereum/eth2.0-specs).
